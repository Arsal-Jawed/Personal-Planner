package application;

import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.mysql.jdbc.PreparedStatement;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class Login {
	
   @FXML
   TextField email;
   @FXML
   PasswordField password;
   @FXML
   Button login;
   @FXML
   Button forgot;
   @FXML
   Button signup;
   @FXML
   Label wrong;
   
   Main m = new Main();
   
   java.sql.PreparedStatement pst;
   
   public void login(ActionEvent e) throws SQLException, IOException {
	   
	   String mail = email.getText().toString();
	   String pass = password.getText().toString();
	   
	   if(email.getText().isEmpty()||password.getText().isEmpty()) {
		   
		   wrong.setText("please enter all credentials");
		   
	   }else {
		   
		   Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/planner","root","");
			PreparedStatement pst = (PreparedStatement) con.prepareStatement("select * from users_accounts where Email=? and Password=?");
			pst.setString(1,mail);
			pst.setString(2,pass);
			ResultSet r = pst.executeQuery();
			
			if(r.next()) {
				
				String user = r.getString("FullName");
				try(FileWriter filewriter = new FileWriter("current.txt")){
					
					filewriter.write(user);
				}
				wrong.setText("");
				m.ChangeScene("Routine.fxml");
			}else {
				
				wrong.setText("incorrect username or password");
			}
	   }
   }
   
   public void signup(ActionEvent e) throws IOException {
	   
	  m.ChangeScene("SignUp.fxml"); 
   }
   
   public void forgot(ActionEvent e) throws IOException {
	   
	   m.ChangeScene("Forget.fxml");
   }

   
}
