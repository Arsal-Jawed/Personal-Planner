package application;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import com.mysql.jdbc.PreparedStatement;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class SignUp {

	@FXML
	TextField name;
	@FXML
	TextField email;
	@FXML
	PasswordField pass;
	@FXML
	PasswordField cpass;
	@FXML
	Button create;
	@FXML
	Button btl;
	@FXML
	Label wrong;
	
	Main m = new Main();
	
	java.sql.PreparedStatement pst;
	
	public void SignUp(ActionEvent e) throws SQLException, IOException {
		
		String n = name.getText().toString();
		String em = email.getText().toString();
		String p = pass.getText().toString();
		String cp = cpass.getText().toString();
		
		if(name.getText().isEmpty()||email.getText().isEmpty()||pass.getText().isEmpty()||
		   cpass.getText().isEmpty()) {
			
			wrong.setText("please enter all credentials");
			
		}else if(!isValidEmail(email.getText())) {
			
			wrong.setText("please enter a valid email");
		
		}else if(pass.getText().length() < 8 || !pass.getText().matches(".*[!@#$%^&*()_+\\-=\\[\\]{};':\"\\\\|,.<>/?].*")){
			
			wrong.setText("password must contains 8 and 1 special character");
			
		}else if(!pass.getText().equals(cpass.getText())) {
			
			wrong.setText("passwords do not match");
		}else {
			
			wrong.setText("");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/planner","root","");
			PreparedStatement pst = (PreparedStatement) con.prepareStatement("insert into users_accounts(FullName,Email,Password) values(?,?,?)");
			
			pst.setString(1,n);
			pst.setString(2,em);
			pst.setString(3,p);
			pst.executeUpdate();
			
			JOptionPane.showMessageDialog(null,"Account Created");
			m.ChangeScene("main.fxml");
		}
	}
	
	public void BTL(ActionEvent e) throws IOException {
		
		m.ChangeScene("main.fxml");
	}
	
	public boolean isValidEmail(String email) {
	    String emailRegex = "^[A-Za-z0-9+_.-]+@(.+)$";
	    Pattern pattern = Pattern.compile(emailRegex);
	    Matcher matcher = pattern.matcher(email);
	    return matcher.matches();
	}
	
}
