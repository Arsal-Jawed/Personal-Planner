package application;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import com.mysql.jdbc.PreparedStatement;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.chart.AreaChart;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class BudgetPlanner {

	@FXML
	Label name;
	@FXML
	TableView<expense> table;
	@FXML
	TableColumn<expense,String> c1 = new TableColumn<>("Expense");
	@FXML
	TableColumn<expense,String> c2 = new TableColumn<>("Amount");
	@FXML
	TextField expense_col;
	@FXML
	TextField amount_col;
	@FXML
	Button AddExpense;
	@FXML
	Button Home;
	@FXML
	Button AboutUs;
	@FXML
	Button Contact;
	@FXML
	Button Logout;
	@FXML
	Button History;
	
	Main m = new Main();
	java.sql.PreparedStatement pst;
	
	public static class expense{
		
		private String exp;
		private String amount;
		
		public expense(String e , String a) {
			
			this.exp = e;
			this.amount = a;
		}
		
		public String getExpense() {return exp;}
		public String getAmount() {return amount;}
	}
	
	@FXML
	public void initialize() throws FileNotFoundException, IOException {
		
		try (BufferedReader reader = new BufferedReader(new FileReader("current.txt"))) {
	    String word = reader.readLine();
	    name.setText(word);
	}
		c1.setCellValueFactory(new PropertyValueFactory<>("Expense"));
		c2.setCellValueFactory(new PropertyValueFactory<>("Amount"));
		
		table.getColumns().addAll(c1,c2);
    }
	
	
	public void GotoHome(ActionEvent e) throws IOException {
		m.ChangeScene("Routine.fxml");
	}
	
	public void LogOut(ActionEvent e) throws IOException {
		m.ChangeScene("main.fxml");
	}
	
	public void CheckHistory(ActionEvent e) throws IOException {
		m.ChangeScene("BudgetHistory.fxml");
	}
	
	public void AddExpense(ActionEvent e) {
		
		String exp = expense_col.getText().toString();
		String amount = amount_col.getText().toString();
		
		if(expense_col.getText().isEmpty()||amount_col.getText().isEmpty()) {
			
			Alert error = new Alert(AlertType.ERROR);
			error.setHeaderText("Empty Fields");
			error.setContentText("please enter expense and amount for adding an expense");
			error.showAndWait();
		}else {
			
			table.getItems().add(new expense(exp,amount));
			expense_col.setText("");
			amount_col.setText("");
		}
	}
	
	/////////////////////////////////////   Earnings   /////////////////////////////////////     Start
	@FXML
	Button salary;
	@FXML
	Button business;
	@FXML
	Button property;
	@FXML
	Button online;
	@FXML
	Button funds;
	@FXML
	Button others;
	@FXML
	AnchorPane Add_Earning;
	@FXML
	Label earning_label;
	@FXML
	TextField earning_field;
	@FXML
	Button SetEarning;
	@FXML
	TextArea TA;
	
	int earn_type;
	int[] EarnArray = {0,0,0,0,0,0};
	
	public void SetEarning(ActionEvent e) {
		
		if(earning_field.getText().isEmpty()) {
			
			Alert error = new Alert(AlertType.ERROR);
			error.setTitle("Error");
			error.setContentText("enter amount for setting earning");
			error.showAndWait();
		}else {
			if(earn_type==1) {EarnArray[0] = Integer.parseInt(earning_field.getText().toString());}
			else    if(earn_type==2) {EarnArray[1] = Integer.parseInt(earning_field.getText().toString());}
			else	if(earn_type==3) {EarnArray[2] = Integer.parseInt(earning_field.getText().toString());}
			else	if(earn_type==4) {EarnArray[3] = Integer.parseInt(earning_field.getText().toString());}
			else	if(earn_type==5) {EarnArray[4] = Integer.parseInt(earning_field.getText().toString());}
			else	if(earn_type==6) {EarnArray[5] = Integer.parseInt(earning_field.getText().toString());}
			
			earning_label.setText("Earning Set, Press OK");
			earning_field.setText("00");
		}		
	}
	
	public void AddEarning(ActionEvent e) {
		
		if(e.getSource().equals(salary)) {earning_label.setText("Salary: "); earn_type = 1;}
   else if(e.getSource().equals(business)) {earning_label.setText("Business: "); earn_type = 2;}
   else if(e.getSource().equals(property)) {earning_label.setText("Property: "); earn_type = 3;}
   else if(e.getSource().equals(online)) {earning_label.setText("Online: "); earn_type = 4;}
   else if(e.getSource().equals(funds)) {earning_label.setText("Funds: "); earn_type = 5;}
   else if(e.getSource().equals(others)) {earning_label.setText("Others: "); earn_type = 6;}
		
		Alert EarnPane = new Alert(AlertType.INFORMATION);
		EarnPane.setTitle("Set Earning");
		EarnPane.setHeaderText(" ");
		EarnPane.setGraphic(Add_Earning);
		Add_Earning.setStyle("-fx-visibility:true");
		EarnPane.showAndWait();
		
	}
	
	/////////////////////////////////////   Earning   ///////////////////////////////////////     End
	
	/////////////////////////////////////   Budget Report   ////////////////////////////////     Start
	@FXML
	TextField saving_field;
	@FXML
	Button UpdateReport;
	@FXML
	Label Total_Expense;
	@FXML
	Label Total_Earning;
	@FXML
	Label Saving_Target;
	@FXML
	Label Achieved_Target;
	@FXML
	PieChart EarnChart;
	@FXML
	AreaChart progress;
	int[] prgs = {1,2,3,0,0,0,0,0,0,0,0,0,0};
	int turn = 3;
	
	public void UpdateReport(ActionEvent e) throws SQLException {
		
		int save;
		if(saving_field.getText().isEmpty()) {saving_field.setText(Saving_Target.getText().replaceAll("[^\\d]", ""));
	                                        	save = Integer.parseInt(saving_field.getText().toString().replaceAll("[^\\d]", "")); 
	}else {save = Integer.parseInt(saving_field.getText().toString().replaceAll("[^\\d]", ""));}
	
		int totalEarn = 0;
		for(int i=0;i<6;i++) {totalEarn += EarnArray[i];}
		
		int totalExpense = 0;
		for(int i=0 ; i<table.getItems().size() ; i++) {
			totalExpense += Integer.parseInt(c2.getCellData(i));
		}
		
		Total_Expense.setText("$"+Integer.toString(totalExpense));
		Total_Earning.setText("$"+Integer.toString(totalEarn));
		Saving_Target.setText("$"+saving_field.getText().toString());
		
		double percent1 = ((double)(totalEarn-totalExpense)/save)*100;
		double percent = Math.round(percent1);
		
		if(percent<=0) {Achieved_Target.setText("0%"); Achieved_Target.setStyle("-fx-text-fill: red");}
   else if(percent<=20&&percent>0) {Achieved_Target.setText(Double.toString(percent)+"%");
           Achieved_Target.setStyle("-fx-text-fill: red"); }
   else if(percent<=40&&percent>20) {Achieved_Target.setText(Double.toString(percent)+"%");
   Achieved_Target.setStyle("-fx-text-fill: orange"); }
   else if(percent<=80&&percent>40) {Achieved_Target.setText(Double.toString(percent)+"%");
   Achieved_Target.setStyle("-fx-text-fill: blue"); }
   else if(percent<=100&&percent>80) {Achieved_Target.setText(Double.toString(percent)+"%");
   Achieved_Target.setStyle("-fx-text-fill: green"); }
   else if(percent>100) {Achieved_Target.setText("100%");
   Achieved_Target.setStyle("-fx-text-fill: light green"); }
		
		int texp = totalExpense;
		int tern = totalEarn;
		int tsave = totalEarn - totalExpense;
		String fileName = "BudgetData.txt";

	        try (FileWriter writer = new FileWriter(fileName)) {
	            writer.write(texp + "\n");
	            writer.write(tern + "\n");
	            writer.write(tsave + "\n");
	        } catch (IOException er) {
	            System.out.println("An error occurred while writing to the file: " + er.getMessage());
	       }
		
		saving_field.setText("");
		
		String[] erns = {"salary","business","property","online","funds","others"};
		EarnChart.getData().clear();
		for(int i=0;i<6;i++) {
			if(EarnArray[i]>0) {
				PieChart.Data data = new PieChart.Data(erns[i],EarnArray[i]);
				EarnChart.getData().add(data);
			}
			
		}
		
		LocalDate currentDate = LocalDate.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        String formattedDate = currentDate.format(formatter);
        
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/planner","root","");
		PreparedStatement pst = (PreparedStatement) con.prepareStatement("insert into budgets(email,date,expense,earning,saving,target,progress) values(?,?,?,?,?,?,?)");
		pst.setString(1,"arsal123@gmail.com");
		pst.setString(2,formattedDate);
		pst.setString(3,Integer.toString(texp));
		pst.setString(4,Integer.toString(tern));
		pst.setString(5,Integer.toString(tsave));
		pst.setString(6,Integer.toString(save));
		pst.setString(7,Achieved_Target.getText().toString());
		pst.executeUpdate();
		
		int progression = (int)percent;
		prgs[turn] = progression;
		turn = (turn+1)%13;
		String pr = " ";
		XYChart.Series<String,Number> Pseries = new XYChart.Series<>();
		for(int i=0 ; i<13 ; i++) {
			if(prgs[i]>0) {
				Pseries.getData().add(new XYChart.Data<String,Number>(pr,prgs[i]));
				pr += " ";
			}else {}
		}
		
		progress.getData().clear();
		progress.getData().add(Pseries);
		Pseries.getNode().setStyle("-fx-stroke: #78daf5;");
		
		int[] topThreeIndexes = new int[3];
	    int[] c2Values = new int[table.getItems().size()];

	    for (int i = 0; i < table.getItems().size(); i++) {
	        c2Values[i] = Integer.parseInt(c2.getCellData(i).toString());
	    }

	    for (int i = 0; i < 3; i++) {
	        int maxIndex = 0;
	        int maxValue = Integer.MIN_VALUE;
	        for (int j = 0; j < c2Values.length; j++) {
	            if (c2Values[j] > maxValue) {
	                maxValue = c2Values[j];
	                maxIndex = j;
	            }
	        }
	        topThreeIndexes[i] = maxIndex;
	        c2Values[maxIndex] = Integer.MIN_VALUE;
	    }
	    String[] topThreeWords = new String[3];
	    for (int i = 0; i < 3; i++) {
	        topThreeWords[i] = c1.getCellData(topThreeIndexes[i]).toString();
	    }
	    
		int sprogress = (int)percent;
		int b = EarnArray[1];
		int f = EarnArray[4];
		int p = EarnArray[2];
		int o = EarnArray[3];
		String es1 = topThreeWords[0];
		String es2 = topThreeWords[1];
		String es3 = topThreeWords[2];
		boolean exb1 = false, exb2 = false;
		if(c2Values[1]>0) {
			exb1 = true;
		}
		
		if(c2Values[2]>0) {
			exb2 = true;
		}
		 if(sprogress<=20) {
    	
          if(b>0) {
        	
        	if(f>0) {
        		
        		if(p>0) {
        			
        			if(o>0) {
        				
        				if(exb1) {
        					
        					if(exb2) {
        						
        						TA.setText("You are very far from your saving goal you \nshould minimize your expenses of "+es1+", "+es2+", "+es3+" \nand you should start investing your Fundings along with property and \nonline income into your business so, it will grow and \nyou earn more or you need to change your business\nbring some new ideas, be patient, and struggle hard\nand you will achieve your saving Goal\nINSHALLAH.");
        					}else {
        						
        						TA.setText("You are very far from your saving goal you \nshould minimize your expenses of "+es1+", "+es2+" \nand you should start investing your Fundings along with property and \nonline income into your business so, it will grow and \nyou earn more or you need to change your business\nbring some new ideas, be patient, and struggle hard\nand you will achieve your saving Goal\nINSHALLAH.");
        					}
        				}else {
        					
        					TA.setText("You are very far from your saving goal you \nshould minimize your expenses of "+es1+" \nand you should start investing your Fundings along with property and \nonline income into your business so, it will grow and \nyou earn more or you need to change your business\nbring some new ideas, be patient, and struggle hard\nand you will achieve your saving Goal\nINSHALLAH.");
        				}
        			}else {
        				
                        if(exb1) {
        					
        					if(exb2) {
        						
        						TA.setText("You are very far from your saving goal you \nshould minimize your expenses of "+es1+", "+es2+", "+es3+" \nand you should start investing your Fundings along with property income\n into your business so, it will grow and \nyou earn more or you need to change your business\nbring some new ideas, be patient, and struggle hard\nand you will achieve your saving Goal\nINSHALLAH.");
        					}else {
        						
        						TA.setText("You are very far from your saving goal you \nshould minimize your expenses of "+es1+", "+es2+" \nand you should start investing your Fundings along with property income\n into your business so, it will grow and \nyou earn more or you need to change your business\nbring some new ideas, be patient, and struggle hard\nand you will achieve your saving Goal\nINSHALLAH.");
        					}
        				}else {
        					
        					TA.setText("You are very far from your saving goal you \nshould minimize your expenses of "+es1+" \nand you should start investing your Fundings along with property income\n into your business so, it will grow and \nyou earn more or you need to change your business\nbring some new ideas, be patient, and struggle hard\nand you will achieve your saving Goal\nINSHALLAH.");
        				}
        		}
        			}else if(p<=0&&o>0) {
        			
                         if(exb1) {
        					
        					if(exb2) {
        						
        						TA.setText("You are very far to your saving goal you \nshould minimize your expenses of "+es1+", "+es2+", "+es3+" \nand you should start investing your Fundings along with \nonline income into your business so, it will grow and \nyou earn more or you need to change your business\nbring some new ideas, be patient, and struggle hard\nand you will achieve your saving Goal\nINSHALLAH.");
        					}else {
        						
        						TA.setText("You are very far to your saving goal you \nshould minimize your expenses of "+es1+", "+es2+" \nand you should start investing your Fundings along with \nonline income into your business so, it will grow and \nyou earn more or you need to change your business\nbring some new ideas, be patient, and struggle hard\nand you will achieve your saving Goal\nINSHALLAH.");
        					}
        				}else {
        					
        					TA.setText("You are very far to your saving goal you \nshould minimize your expenses of "+es1+" \nand you should start investing your Fundings along with \nonline income into your business so, it will grow and \nyou earn more or you need to change your business\nbring some new ideas, be patient, and struggle hard\nand you will achieve your saving Goal\nINSHALLAH.");
        				}
        				
        		}else {
        			
        			if(exb1) {
    					
    					if(exb2) {
    						
    						TA.setText("You are very far to your saving goal you \nshould minimize your expenses of "+es1+", "+es2+", "+es3+" \nand you should start investing your Fundings \ninto your business so, it will grow and \nyou earn more or you need to change your business\nbring some new ideas, be patient, and struggle hard\nand you will achieve your saving Goal\nINSHALLAH.");
    					}else {
    						
    						TA.setText("You are very far to your saving goal you \nshould minimize your expenses of "+es1+", "+es2+" \nand you should start investing your Fundings along with \ninto your business so, it will grow and \nyou earn more or you need to change your business\nbring some new ideas, be patient, and struggle hard\nand you will achieve your saving Goal\nINSHALLAH.");
    					}
    				}else {
    					
    					TA.setText("You are very far to your saving goal you \nshould minimize your expenses of "+es1+" \nand you should start investing your Fundings \ninto your business so, it will grow and \nyou earn more or you need to change your business\nbring some new ideas, be patient, and struggle hard\nand you will achieve your saving Goal\nINSHALLAH.");
    				}
        		}
        	}else {
        		
                 if(p>0) {
        			
        			if(o>0) {
        				
        				if(exb1) {
        					
        					if(exb2) {
        						
        						TA.setText("You are very far from your saving goal you \nshould minimize your expenses of "+es1+", "+es2+", "+es3+" \nand you should start investing your property and \nonline income into your business so, it will grow and \nyou earn more or you need to change your business\nbring some new ideas, be patient, and struggle hard\nand you will achieve your saving Goal\nINSHALLAH.");
        					}else {
        						
        						TA.setText("You are very far from your saving goal you \nshould minimize your expenses of "+es1+", "+es2+" \nand you should start investing your property and \nonline income into your business so, it will grow and \nyou earn more or you need to change your business\nbring some new ideas, be patient, and struggle hard\nand you will achieve your saving Goal\nINSHALLAH.");
        					}
        				}else {
        					
        					TA.setText("You are very far from your saving goal you \nshould minimize your expenses of "+es1+" \nand you should start investing your property and \nonline income into your business so, it will grow and \nyou earn more or you need to change your business\nbring some new ideas, be patient, and struggle hard\nand you will achieve your saving Goal\nINSHALLAH.");
        				}
        			}else {
        				
                        if(exb1) {
        					
        					if(exb2) {
        						
        						TA.setText("You are very far from your saving goal you \nshould minimize your expenses of "+es1+", "+es2+", "+es3+" \nand you should start investing your property income\n into your business so, it will grow and \nyou earn more or you need to change your business\nbring some new ideas, be patient, and struggle hard\nand you will achieve your saving Goal\nINSHALLAH.");
        					}else {
        						
        						TA.setText("You are very far from your saving goal you \nshould minimize your property income\n into your business so, it will grow and \nyou earn more or you need to change your business\nbring some new ideas, be patient, and struggle hard\nand you will achieve your saving Goal\nINSHALLAH.");
        					}
        				}else {
        					
        					TA.setText("You are very far from your saving goal you \nshould minimize your expenses of "+es1+" \nand you should start investing your property income\n into your business so, it will grow and \nyou earn more or you need to change your business\nbring some new ideas, be patient, and struggle hard\nand you will achieve your saving Goal\nINSHALLAH.");
        				}
        		}
        			}else if(p<=0&&o>0) {
        			
                         if(exb1) {
        					
        					if(exb2) {
        						
        						TA.setText("You are very far to your saving goal you \nshould minimize your expenses of "+es1+", "+es2+", "+es3+" \nand you should start investing your online income\ninto your business so, it will grow and \nyou earn more or you need to change your business\nbring some new ideas, be patient, and struggle hard\nand you will achieve your saving Goal\nINSHALLAH.");
        					}else {
        						
        						TA.setText("You are very far to your saving goal you \nshould minimize your expenses of "+es1+", "+es2+" \nand you should start investing your online income\ninto your business so, it will grow and \nyou earn more or you need to change your business\nbring some new ideas, be patient, and struggle hard\nand you will achieve your saving Goal\nINSHALLAH.");
        					}
        				}else {
        					
        					TA.setText("You are very far to your saving goal you \nshould minimize your expenses of "+es1+" \nand you should start investing your online income\ninto your business so, it will grow and \nyou earn more or you need to change your business\nbring some new ideas, be patient, and struggle hard\nand you will achieve your saving Goal\nINSHALLAH.");
        				}
        				
        		}else {
        			
                     if(exb1) {
    					
    					if(exb2) {
    						
    						TA.setText("You are very far to your saving goal you \nshould minimize your expenses of "+es1+", "+es2+", "+es3+" \nand you should start investing \ninto your business so, it will grow and \nyou earn more or you need to change your business\nbring some new ideas, be patient, and struggle hard\nand you will achieve your saving Goal\nINSHALLAH.");
    					}else {
    						
    						TA.setText("You are very far to your saving goal you \nshould minimize your expenses of "+es1+", "+es2+" \nand you should start investing \ninto your business so, it will grow and \nyou earn more or you need to change your business\nbring some new ideas, be patient, and struggle hard\nand you will achieve your saving Goal\nINSHALLAH.");
    					}
    				}else {
    					
    					TA.setText("You are very far to your saving goal you \nshould minimize your expenses of "+es1+" \nand you should start investing \ninto your business so, it will grow and \nyou earn more or you need to change your business\nbring some new ideas, be patient, and struggle hard\nand you will achieve your saving Goal\nINSHALLAH.");
    				}
        		}
        	}
      }else {
        	
    	  if(f>0) {
      		
      		if(p>0) {
      			
      			if(o>0) {
      				
      				if(exb1) {
      					
      					if(exb2) {
      						
      						TA.setText("You are very far from your saving goal you \nshould minimize your expenses of "+es1+", "+es2+", "+es3+" \nand bring some new ideas and start some business\nuse your fundings along with your property and online \nincome as your investment and work hard, be patient\nand you will achieve your saving Goal\nINSHALLAH");
      					}else {
      						
      						TA.setText("You are very far from your saving goal you \nshould minimize your expenses of "+es1+", "+es2+" \nand bring some new ideas and start some business\nuse your fundings along with your property and online \nincome as your investment and work hard, be patient\nand you will achieve your saving Goal\nINSHALLAH");
      					}
      				}else {
      					
      					TA.setText("You are very far from your saving goal you \nshould minimize your expenses of "+es1+" \nand bring some new ideas and start some business\nuse your fundings along with your property and online \nincome as your investment and work hard, be patient\nand you will achieve your saving Goal\nINSHALLAH");
      				}
      			}else {
      				
                      if(exb1) {
      					
      					if(exb2) {
      						
      						TA.setText("You are very far from your saving goal you \nshould minimize your expenses of "+es1+", "+es2+", "+es3+" \nand bring some new ideas and start some business\nuse your fundings along with your property income\nas your investment and work hard, be patient\nand you will achieve your saving Goal\nINSHALLAH");
      					}else {
      						
      						TA.setText("You are very far from your saving goal you \nshould minimize your expenses of "+es1+", "+es2+" \nand bring some new ideas and start some business\nuse your fundings along with your property income\nas your investment and work hard, be patient\nand you will achieve your saving Goal\nINSHALLAH");
      					}
      				}else {
      					
      					TA.setText("You are very far from your saving goal you \nshould minimize your expenses of "+es1+" \nand bring some new ideas and start some business\nuse your fundings along with your property income \nas your investment and work hard, be patient\nand you will achieve your saving Goal\nINSHALLAH");
      				}
      		}
      			}else if(p<=0&&o>0) {
      			
                      if(exb1) {
      					
      					if(exb2) {
      						
      						TA.setText("You are very far from your saving goal you \nshould minimize your expenses of "+es1+", "+es2+", "+es3+" \nand bring some new ideas and start some business\nuse your fundings along with your online \nincome as your investment and work hard, be patient\nand you will achieve your saving Goal\nINSHALLAH");
      					}else {
      						
      						TA.setText("You are very far from your saving goal you \nshould minimize your expenses of "+es1+", "+es2+" \nand bring some new ideas and start some business\nuse your fundings along with your online \nincome as your investment and work hard, be patient\nand you will achieve your saving Goal\nINSHALLAH");
      					}
      				}else {
      					
      					TA.setText("You are very far from your saving goal you \nshould minimize your expenses of "+es1+" \nand bring some new ideas and start some business\nuse your fundings along with your online \nincome as your investment and work hard, be patient\nand you will achieve your saving Goal\nINSHALLAH");
      				}
      				
      		}else {
      			
      			if(exb1) {
  					
  					if(exb2) {
  						
  						TA.setText("You are very far from your saving goal you \nshould minimize your expenses of "+es1+", "+es2+", "+es3+" \nand bring some new ideas and start some business\nwork hard, be patient\nand you will achieve your saving Goal\nINSHALLAH");
  					}else {
  						
  						TA.setText("You are very far from your saving goal you \nshould minimize your expenses of "+es1+", "+es2+" \nand bring some new ideas and start some business\nwork hard, be patient\nand you will achieve your saving Goal\nINSHALLAH");
  					}
  				}else {
  					
  					TA.setText("You are very far from your saving goal you \nshould minimize your expenses of "+es1+" \nand bring some new ideas and start some business\nwork hard, be patient\nand you will achieve your saving Goal\nINSHALLAH");
  				}
      		}
      	}else {
      		
            if(p>0) {
      			
      			if(o>0) {
      				
      				if(exb1) {
      					
      					if(exb2) {
      						
      						TA.setText("You are very far from your saving goal you \nshould minimize your expenses of "+es1+", "+es2+", "+es3+" \nand bring some new ideas and start some business\nuse your property and online \nincome as your investment and work hard, be patient\nand you will achieve your saving Goal\nINSHALLAH");
      					}else {
      						
      						TA.setText("You are very far from your saving goal you \nshould minimize your expenses of "+es1+", "+es2+" \nand bring some new ideas and start some business\nuse your property and online \nincome as your investment and work hard, be patient\nand you will achieve your saving Goal\nINSHALLAH");
      					}
      				}else {
      					
      					TA.setText("You are very far from your saving goal you \nshould minimize your expenses of "+es1+" \nand bring some new ideas and start some business\nuse your property and online \nincome as your investment and work hard, be patient\nand you will achieve your saving Goal\nINSHALLAH");
      				}
      			}else {
      				
                      if(exb1) {
      					
      					if(exb2) {
      						
      						TA.setText("You are very far from your saving goal you \nshould minimize your expenses of "+es1+", "+es2+", "+es3+" \nand bring some new ideas and start some business\nuse your property income\nas your investment and work hard, be patient\nand you will achieve your saving Goal\nINSHALLAH");
      					}else {
      						
      						TA.setText("You are very far from your saving goal you \nshould minimize your expenses of "+es1+", "+es2+" \nand bring some new ideas and start some business\nuse your property income\nas your investment and work hard, be patient\nand you will achieve your saving Goal\nINSHALLAH");
      					}
      				}else {
      					
      					TA.setText("You are very far from your saving goal you \nshould minimize your expenses of "+es1+" \nand bring some new ideas and start some business\nuse your property income \nas your investment and work hard, be patient\nand you will achieve your saving Goal\nINSHALLAH");
      				}
      		}
      			}else if(p<=0&&o>0) {
      			
                      if(exb1) {
      					
      					if(exb2) {
      						
      						TA.setText("You are very far from your saving goal you \nshould minimize your expenses of "+es1+", "+es2+", "+es3+" \nand bring some new ideas and start some business\nuse your online \nincome as your investment and work hard, be patient\nand you will achieve your saving Goal\nINSHALLAH");
      					}else {
      						
      						TA.setText("You are very far from your saving goal you \nshould minimize your expenses of "+es1+", "+es2+" \nand bring some new ideas and start some business\nuse your online \nincome as your investment and work hard, be patient\nand you will achieve your saving Goal\nINSHALLAH");
      					}
      				}else {
      					
      					TA.setText("You are very far from your saving goal you \nshould minimize your expenses of "+es1+" \nand bring some new ideas and start some business\nuse your online \nincome as your investment and work hard, be patient\nand you will achieve your saving Goal\nINSHALLAH");
      				}
      				
      		}else {
      			
                 if(exb1) {
  					
  					if(exb2) {
  						
  						TA.setText("You are very far from your saving goal you \nshould minimize your expenses of "+es1+", "+es2+", "+es3+" \nand bring some new ideas and start some business\nwork hard, be patient\nand you will achieve your saving Goal\nINSHALLAH");
  					}else {
  						
  						TA.setText("You are very far from your saving goal you \nshould minimize your expenses of "+es1+", "+es2+" \nand bring some new ideas and start some business\nwork hard, be patient\nand you will achieve your saving Goal\nINSHALLAH");
  					}
  				}else {
  					
  					TA.setText("You are very far from your saving goal you \nshould minimize your expenses of "+es1+" \nand bring some new ideas and start some business\nwork hard, be patient\nand you will achieve your saving Goal\nINSHALLAH");
  				}
      		}
      	}
        }
    	
    }else if(sprogress>20&&sprogress<=70) {
    	
    	if(b>0) {
        	
        	if(f>0) {
        		
        		if(p>0) {
        			
        			if(o>0) {
        				
        				if(exb1) {
        					
        					if(exb2) {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+", "+es3+" \nand save your Fundings with this you should invest \ninto your property and online income in your \nbusiness so it grow and you earn more.");
        					}else {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+" \nand save your Fundings with this you should invest \ninto your property and online income in your \nbusiness so it grow and you earn more.");
        					}
        				}else {
        					
        					TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+" \nand save your Fundings with this you should invest \ninto your property and online income in your \nbusiness so it grow and you earn more.");
        				}
        			}else {
        				
                       if(exb1) {
        					
        					if(exb2) {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+", "+es3+" \nand save your Fundings with this you should invest \ninto your property income in your \nbusiness so it grow and you earn more.");
        					}else {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+" \nand save your Fundings with this you should invest \ninto your property income in your \nbusiness so it grow and you earn more.");
        					}
        				}else {
        					
        					TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+" \nand save your Fundings with this you should invest \ninto your property income in your \nbusiness so it grow and you earn more.");
        				}
        			}
        		}else if(p<=0&&o>0) {
        			
        			if(exb1) {
    					
    					if(exb2) {
    						
    						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+", "+es3+" \nand save your Fundings with this you should invest \ninto your online income in your \nbusiness so it grow and you earn more.");
    					}else {
    						
    						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+" \nand save your Fundings with this you should invest \ninto your online income in your \nbusiness so it grow and you earn more.");
    					}
    				}else {
    					
    					TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+" \nand save your Fundings with this you should invest \ninto your property online income in your \nbusiness so it grow and you earn more.");
    				}
        		}else {
        			
                       if(exb1) {
    					
    					if(exb2) {
    						
    						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+", "+es3+" \nand save your Fundings with this you should invest it\ninto your business so it grow and you earn more.");
    					}else {
    						
    						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+" \nand save your Fundings with this you should invest it\ninto your business so it grow and you earn more.");
    					}
    				}else {
    					
    					TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+" \nand save your Fundings with this you should invest it\ninto your business so it grow and you earn more.");
    				}
        		}
        	}else {
        		
                 if(p>0) {
        			
        			if(o>0) {
        				
        				if(exb1) {
        					
        					if(exb2) {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+", "+es3+" \nand with this you should invest \ninto your property and online income in your \nbusiness so it grow and you earn more.");
        					}else {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+" \nand with this you should invest \ninto your property and online income in your \nbusiness so it grow and you earn more.");
        					}
        				}else {
        					
        					TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+" \nand with this you should invest \ninto your property and online income in your \nbusiness so it grow and you earn more.");
        				}
        			}else {
        				
                       if(exb1) {
        					
        					if(exb2) {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+", "+es3+" \nand with this you should invest \ninto your property income in your \nbusiness so it grow and you earn more.");
        					}else {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+" \nand with this you should invest \ninto your property income in your \nbusiness so it grow and you earn more.");
        					}
        				}else {
        					
        					TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+" \nand with this you should invest \ninto your property income in your \nbusiness so it grow and you earn more.");
        				}
        			}
        		}else if(p<=0&&o>0) {
        			
        			if(exb1) {
    					
    					if(exb2) {
    						
    						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+", "+es3+" \nand with this you should invest \ninto your online income in your \nbusiness so it grow and you earn more.");
    					}else {
    						
    						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+" \nand with this you should invest \ninto your online income in your \nbusiness so it grow and you earn more.");
    					}
    				}else {
    					
    					TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+" \nand with this you should invest \ninto your property online income in your \nbusiness so it grow and you earn more.");
    				}
        		}else {
        			
                      if(exb1) {
    					
    					if(exb2) {
    						
    						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+", "+es3+" \nand with this you should invest \ninto your business so it grow and you earn more.");
    					}else {
    						
    						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+" \nand with this you should invest \ninto business so it grow and you earn more.");
    					}
    				}else {
    					
    					TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+" \nand with this you should invest \ninto your business so it grow and you earn more.");
    				}
        		}
        	}
        }else {
        	
               if(f>0) {
        		
        		if(p>0) {
        			
        			if(o>0) {
        				
        				if(exb1) {
        					
        					if(exb2) {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+", "+es3+" \nand save your Fundings with this you should invest \nyour property and online income to start a \nbusiness so you can earn more.");
        					}else {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+" \nand save your Fundings with this you should invest \ninto your property and online income to start a \nbusiness so you can earn more.");
        					}
        				}else {
        					
        					TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+" \nand save your Fundings with this you should invest \ninto your property and online income to start a \nbusiness so you can earn more.");
        				}
        			}else {
        				
                       if(exb1) {
        					
        					if(exb2) {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+", "+es3+" \nand save your Fundings with this you should invest \ninto your property income to start a\nbusiness so you can earn more.");
        					}else {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+" \nand save your Fundings with this you should invest \ninto your property income to start \nbusiness so you can earn more.");
        					}
        				}else {
        					
        					TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+" \nand save your Fundings with this you should invest \ninto your property income to start \nbusiness so you can earn more.");
        				}
        			}
        		}else if(p<=0&&o>0) {
        			
        			if(exb1) {
    					
    					if(exb2) {
    						
    						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+", "+es3+" \nand save your Fundings with this you should invest \ninto your online income to start \nbusiness so you can earn more.");
    					}else {
    						
    						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+" \nand save your Fundings with this you should invest \ninto your online income to start \nbusiness so you can earn more.");
    					}
    				}else {
    					
    					TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+" \nand save your Fundings with this you should invest \ninto your property online income to start \nbusiness so you can earn more.");
    				}
        		}else {
        			
                     if(exb1) {
    					
    					if(exb2) {
    						
    						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+", "+es3+" \nand save your Fundings with this you should invest \ninto your business so you can earn more.");
    					}else {
    						
    						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+" \nand save your Fundings with this you should invest \ninto your business so you can earn more.");
    					}
    				}else {
    					
    					TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+" \nand save your Fundings with this you should invest \ninto your business so you can earn more.");
    				}
        		}
        	}else {
        		
                 if(p>0) {
        			
        			if(o>0) {
        				
        				if(exb1) {
        					
        					if(exb2) {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+", "+es3+" \nand with this you should invest \ninto your property and online income to start \nbusiness so you can earn more.");
        					}else {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+" \nand with this you should invest \ninto your property and online income to start \nbusiness so you can earn more.");
        					}
        				}else {
        					
        					TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+" \nand with this you should invest \ninto your property and online income to start \nbusiness so you can earn more.");
        				}
        			}else {
        				
                       if(exb1) {
        					
        					if(exb2) {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+", "+es3+" \nand with this you should invest \ninto your property income to start \nbusiness so you can earn more.");
        					}else {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+" \nand with this you should invest \ninto your property income to start \nbusiness so you can earn more.");
        					}
        				}else {
        					
        					TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+" \nand with this you should invest \ninto your property income to start \nbusiness so you can earn more.");
        				}
        			}
        		}else if(p<=0&&o>0) {
        			
        			if(exb1) {
    					
    					if(exb2) {
    						
    						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+", "+es3+" \nand with this you should invest \ninto your online income to start \nbusiness so you can earn more.");
    					}else {
    						
    						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+" \nand with this you should invest \ninto your online income to start \nbusiness so you can earn more.");
    					}
    				}else {
    					
    					TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+" \nand with this you should invest \ninto your property online income to start \nbusiness so you can earn more.");
    				}
        		}else {
        			
                      if(exb1) {
    					
    					if(exb2) {
    						
    						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+", "+es3+" \nand with this you should invest \ninto your business so you can earn more.");
    					}else {
    						
    						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+" \nand with this you should invest \ninto your business so you can earn more.");
    					}
    				}else {
    					
    					TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+" \nand with this you should invest \ninto your business so you can earn more.");
    				}
        		}
        	}
        }
    }else if(sprogress>70&&sprogress<=90) {
    	
          if(b>0) {
        	
        	if(f>0) {
        		
        		if(p>0) {
        			
        			if(o>0) {
        				
        				if(exb1) {
        					
        					if(exb2) {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+", "+es3+" \nand you should start investing your Fundings along with property and \nonline income into your business so, it will grow and \nyou earn more.");
        					}else {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+",  \nand you should start investing your Fundings along with property and \nonline income into your business so, it will grow and \nyou earn more.");
        					}
        				}else {
        					
        					TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+" \nand you should start investing your Fundings along with property and \nonline income into your business so, it will grow and \nyou earn more.");
        				}
        			}else {
        				
                          if(exb1) {
        					
        					if(exb2) {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+", "+es3+" \nand you should start investing your Fundings along with property\nincome into your business so, it will grow and \nyou earn more.");
        					}else {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+",  \nand you should start investing your Fundings along with property\nincome into your business so, it will grow and \nyou earn more.");
        					}
        				}else {
        					
        					TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+" \nand you should start investing your Fundings along with property\nincome into your business so, it will grow and \nyou earn more.");
        				}
        		}
        			}else if(p<=0&&o>0) {
        			
                          if(exb1) {
        					
        					if(exb2) {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+", "+es3+" \nand you should start investing your Fundings along with\nonline income into your business so, it will grow and \nyou earn more.");
        					}else {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+",  \nand you should start investing your Fundings along with\nonline income into your business so, it will grow and \nyou earn more.");
        					}
        				}else {
        					
        					TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+" \nand you should start investing your Fundings along with\nonline income into your business so, it will grow and \nyou earn more.");
        				}
        		}else {
        			
        			if(exb1) {
    					
    					if(exb2) {
    						
    						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+", "+es3+" \nand you should start investing your Fundings\ninto your business so, it will grow and \nyou earn more.");
    					}else {
    						
    						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+",  \nand you should start investing your Fundings\ninto your business so, it will grow and \nyou earn more.");
    					}
    				}else {
    					
    					TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+" \nand you should start investing your Fundings\ninto your business so, it will grow and \nyou earn more.");
    				}
        		}
        	}else {
        		
                 if(p>0) {
        			
        			if(o>0) {
        				
        				if(exb1) {
        					
        					if(exb2) {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+", "+es3+" \nand you should start investing your property and \nonline income into your business so, it will grow and \nyou earn more.");
        					}else {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+",  \nand you should start investing your property and \nonline income into your business so, it will grow and \nyou earn more.");
        					}
        				}else {
        					
        					TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+" \nand you should start investing your property and \nonline income into your business so, it will grow and \nyou earn more.");
        				}
        			}else {
        				
                          if(exb1) {
        					
        					if(exb2) {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+", "+es3+" \nand you should start investing your property\nincome into your business so, it will grow and \nyou earn more.");
        					}else {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+",  \nand you should start investing your property\nincome into your business so, it will grow and \nyou earn more.");
        					}
        				}else {
        					
        					TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+" \nand you should start investing your property\nincome into your business so, it will grow and \nyou earn more.");
        				}
        		}
        			}else if(p<=0&&o>0) {
        			
                          if(exb1) {
        					
        					if(exb2) {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+", "+es3+" \nand you should start investing your Funding online income \ninto your business so, it will grow and \nyou earn more.");
        					}else {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+",  \nand you should start investing your online income \ninto your business so, it will grow and \nyou earn more.");
        					}
        				}else {
        					
        					TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+" \nand you should start investing your online income \ninto your business so, it will grow and \nyou earn more.");
        				}
        		}else {
        			
        			if(exb1) {
    					
    					if(exb2) {
    						
    						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+", "+es3+" \nand you should start investing\ninto your business so, it will grow and \nyou earn more.");
    					}else {
    						
    						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+",  \nand you should start investing \ninto your business so, it will grow and \nyou earn more.");
    					}
    				}else {
    					
    					TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+" \nand you should start investing\ninto your business so, it will grow and \nyou earn more.");
    				}
        		}
        	}
        }else {
        	
             if(f>0) {
        		
        		if(p>0) {
        			
        			if(o>0) {
        				
        				if(exb1) {
        					
        					if(exb2) {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+", "+es3+" \nand with your fundings and your property and online income\nstart some business so, it will grow and \nyou earn more.");
        					}else {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+"\nand with your fundings and your property and online income\nstart some business so, it will grow and \nyou earn more.");
        					}
        				}else {
        					
        					TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+"\nand with your fundings and your property and online income\nstart some business so, it will grow and \nyou earn more.");
        				}
        			}else {
        				
                        if(exb1) {
        					
        					if(exb2) {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+", "+es3+" \nand with your fundings and your property income\nstart some business so, it will grow and \nyou earn more.");
        					}else {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+"\nand with your fundings and your property income\nstart some business so, it will grow and \nyou earn more.");
        					}
        				}else {
        					
        					TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+"\nand with your fundings and your property income\nstart some business so, it will grow and \nyou earn more.");
        				}
        		}
        			}else if(p<=0&&o>0) {
        			
                         if(exb1) {
        					
        					if(exb2) {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+", "+es3+" \nand with your fundings and your online income\nstart some business so, it will grow and \nyou earn more.");
        					}else {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+"\nand with your fundings and your online income\nstart some business so, it will grow and \nyou earn more.");
        					}
        				}else {
        					
        					TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+"\nand with your fundings and your online income\nstart some business so, it will grow and \nyou earn more.");
        				}
        		}else {
        			
        			if(exb1) {
    					
    					if(exb2) {
    						
    						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+", "+es3+" \nand with your fundings\nstart some business so, it will grow and \nyou earn more.");
    					}else {
    						
    						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+"\nand with your fundings\nstart some business so, it will grow and \nyou earn more.");
    					}
    				}else {
    					
    					TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+"\nand with your fundings\nstart some business so, it will grow and \nyou earn more.");
    				}
        		}
        	}else {
        		
                if(p>0) {
        			
        			if(o>0) {
        				
        				if(exb1) {
        					
        					if(exb2) {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+", "+es3+" \nand with your property and online income\nstart some business so, it will grow and \nyou earn more.");
        					}else {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+"\nand with your property and online income\nstart some business so, it will grow and \nyou earn more.");
        					}
        				}else {
        					
        					TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+"\nand with your property and online income\nstart some business so, it will grow and \nyou earn more.");
        				}
        			}else {
        				
                        if(exb1) {
        					
        					if(exb2) {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+", "+es3+" \nand with your property income\nstart some business so, it will grow and \nyou earn more.");
        					}else {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+"\nand with your property income\nstart some business so, it will grow and \nyou earn more.");
        					}
        				}else {
        					
        					TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+"\nand with your property income\nstart some business so, it will grow and \nyou earn more.");
        				}
        		}
        			}else if(p<=0&&o>0) {
        			
                         if(exb1) {
        					
        					if(exb2) {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+", "+es3+" \nand with your online income\nstart some business so, it will grow and \nyou earn more.");
        					}else {
        						
        						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+"\nand with your online income\nstart some business so, it will grow and \nyou earn more.");
        					}
        				}else {
        					
        					TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+"\nand with your online income\nstart some business so, it will grow and \nyou earn more.");
        				}
        		}else {
        			
        			if(exb1) {
    					
    					if(exb2) {
    						
    						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+", "+es2+", "+es3+"and \nstart some business so, it will grow and \nyou earn more.");
    					}else {
    						
    						TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+"\nand start some business so, it will grow and \nyou earn more.");
    					}
    				}else {
    					
    					TA.setText("For achieving your Saving goal you have to \nMinimize your expenses of "+es1+"\nand start some business so, it will grow and \nyou earn more.");
    				}
        		}
        	}
        }
    }else if(sprogress>=90&&sprogress<100){
    	
    	if(exb1) {
			
			if(exb2) {
				
				TA.setText("You are already very near to you goal \n just minimize your expenses of "+es1+", "+es2+", "+es3+" \nand with this you will be able to\nachieve your Saving Goal.");
			}else {
				
				TA.setText("You are already very near to you goal \n just minimize your expenses of "+es1+", "+es2+"\nand with this you will be able to\nachieve your Saving Goal.");
			}
		}else {
			
			TA.setText("You are already very near to you goal \n just minimize your expenses of "+es1+", "+es2+" \nand with this you will be able to\nachieve your Saving Goal.");
		}
    	
    }else if(sprogress>=100) {
    	
    	TA.setText("Congratulations, Alhamdulillah You have already achieved your Saving Goal");
    }
		 
	}
}