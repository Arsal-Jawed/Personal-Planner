package application;

import java.io.IOException;
import java.net.URL;

import javafx.scene.Node;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ResourceBundle;

import com.mysql.jdbc.PreparedStatement;

public class SetRoutine implements javafx.fxml.Initializable {

	@FXML
	TextField task1;
	@FXML
	TextField task2;
	@FXML
	TextField task3;
	@FXML
	TextField task4;
	@FXML
	TextField task5;
	@FXML
	TextField task6;
	@FXML
	TextField task7;
	@FXML
	TextField task8;
	@FXML
	TextField task9;
	@FXML
	TextField task10;
	@FXML
	TextField from1;
	@FXML
	TextField from2;
	@FXML
	TextField from3;
	@FXML
	TextField from4;
	@FXML
	TextField from5;
	@FXML
	TextField from6;
	@FXML
	TextField from7;
	@FXML
	TextField from8;
	@FXML
	TextField from9;
	@FXML
	TextField from10;
	@FXML
	TextField to1;
	@FXML
	TextField to2;
	@FXML
	TextField to3;
	@FXML
	TextField to4;
	@FXML
	TextField to5;
	@FXML
	TextField to6;
	@FXML
	TextField to7;
	@FXML
	TextField to8;
	@FXML
	TextField to9;
	@FXML
	TextField to10;
	@FXML
	Button SetTasks;
	@FXML
	Button Cancel;
	
	Main m = new Main();
	
	java.sql.PreparedStatement pst;
	
	 @FXML
	    private Node root;

	    @Override
	    public void initialize(URL location, ResourceBundle resources) {
	        // Initialization code
	    }

	    public Node getRoot() {
	        return root;
	    }
	
	public void SetTasks(ActionEvent e) throws IOException, SQLException {
		
		String[] tasks = new String[10];
		String[] fromTimes = new String[10];
		String[] toTimes = new String[10];
		
		TextField[] tfs = {task1,task2,task3,task4,task5,task6,task7,task8,task9,task10};
		TextField[] fts = {from1,from2,from3,from4,from5,from6,from7,from8,from9,from10};
		TextField[] tts = {to1,to2,to3,to4,to5,to6,to7,to8,to9,to10};
		
		for(int i=0 ; i<10 ; i++) {
			
			if(tfs[i].getText().isEmpty()) {
				tasks[i] = "Not Set";
			}else {
				tasks[i] = tfs[i].getText().toString();
			}
			
			fromTimes[i] = fts[i].getText().toString();
			toTimes[i] = tts[i].getText().toString();
		}
        
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/planner","root","");
		
		PreparedStatement pst2 = (PreparedStatement) con.prepareStatement("delete from routinetasks");
		pst2.execute();
		PreparedStatement pst = (PreparedStatement) con.prepareStatement("insert into routinetasks(Email,Task,Time1,Time2) values(?,?,?,?)");
		
		for(int i=0 ; i<10 ; i++) {
			
			pst.setString(1,"arsal123@gmail.com");
			pst.setString(2, tasks[i]);
			pst.setString(3, fromTimes[i]);
			pst.setString(4, toTimes[i]);
			pst.executeUpdate();
		}
		
		m.ChangeScene("Routine.fxml");
	}
	
    public void Cancel(ActionEvent e) throws IOException {
		
		m.ChangeScene("Routine.fxml");
	}
}
