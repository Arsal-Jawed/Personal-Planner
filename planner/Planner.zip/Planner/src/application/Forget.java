package application;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JOptionPane;

import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.Statement;

public class Forget {

	@FXML
	TextField email;
	@FXML
	PasswordField pass;
	@FXML
	PasswordField cpass;
	@FXML
	Button reset;
	@FXML
	Button update;
	@FXML
	Button btl;
	@FXML
	Label wrong;
	@FXML
	Label wrongmail;
	@FXML
	AnchorPane newpass;
	
	Main m = new Main();
	
	java.sql.PreparedStatement pst;
	
	
	
	public void ResetPass(ActionEvent e) throws SQLException {
		
		String mail = email.getText().toString();
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/planner","root","");
		Statement stm = (Statement) con.createStatement();
		String cmd = "Select * from users_accounts where Email='"+mail+"'";
		ResultSet res = stm.executeQuery(cmd);
		
		boolean exists = false;
		
		while(res.next()) {
			
			exists = true;
		}
		
		if(email.getText().isEmpty()) {
			
			wrongmail.setText("please enter your email");
			
		}else {
			
			if(!exists) {
				
				wrongmail.setText("email not found");
				
			}else {
				
				newpass.setStyle("-fx-visibility: true");
			}
		}
	}
	
	public void UpdatePass(ActionEvent e) throws SQLException, IOException {
		
		String p = pass.getText().toString();
		String cp = cpass.getText().toString();
		String mail = email.getText().toString();
		
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/planner","root","");
		
		if(pass.getText().isEmpty()||cpass.getText().isEmpty()) {
			
			wrong.setText("please enter both credentials");
		}else if(pass.getText().length() < 8 || !pass.getText().matches(".*[!@#$%^&*()_+\\-=\\[\\]{};':\"\\\\|,.<>/?].*")) {
			
			wrong.setText("password must contains 8 and 1 special character");
		}else if(!p.equals(cp)) {
			
			
			wrong.setText("passwords do not match");
		}else {
			
			PreparedStatement stm = (PreparedStatement) con.prepareStatement("Update users_accounts set Password=? Where Email=?");
			stm.setString(1,p);
			stm.setString(2,mail);
			stm.executeUpdate();
			wrong.setText("");
			JOptionPane.showMessageDialog(null,"Password Updated");
			m.ChangeScene("main.fxml");
		}
		
	}
	
	public void BTL(ActionEvent e) throws IOException {
		
		m.ChangeScene("main.fxml");
	}
}
