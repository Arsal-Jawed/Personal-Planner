package application;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.mysql.jdbc.PreparedStatement;

public class BudgetHistory {

	@FXML
	Button BacktoPlanner;
	@FXML
	TableView<budgets> table;
	@FXML
	TableColumn<budgets,String> b1 = new TableColumn<>("Date");
	@FXML
	TableColumn<budgets,String> b2 = new TableColumn<>("Total_Expense");
	@FXML
	TableColumn<budgets,String> b3 = new TableColumn<>("Total_Earning");
	@FXML
	TableColumn<budgets,String> b4 = new TableColumn<>("Total_Saving");
	@FXML
	TableColumn<budgets,String> b5 = new TableColumn<>("Saving_Target");
	@FXML
	TableColumn<budgets,String> b6 = new TableColumn<>("Progress");
	
	Main m = new Main();
	java.sql.PreparedStatement pst;
	
	public void BacktoPlanner(ActionEvent e) throws IOException {
		m.ChangeScene("BudgetPlanner.fxml");
	}
	
	public static class budgets{
		
		private String Date;
		private String Total_Expense;
		private String Total_Earning;
		private String Total_Saving;
		private String Saving_Target;
		private String Progress;
		
		public budgets(String d , String ex , String en , String sv , String trg , String prg) {
			
			this.Date = d;
			this.Total_Expense = ex;
			this.Total_Earning = en;
			this.Total_Saving = sv;
			this.Saving_Target = trg;
			this.Progress = prg;
		}
		
		public String getDate() {return Date;}
		public String getTotal_Expense() {return Total_Expense;}
		public String getTotal_Earning() {return Total_Earning;}
		public String getTotal_Saving() {return Total_Saving;}
		public String getSaving_Target() {return Saving_Target;}
		public String getProgress() {return Progress;}
	}
	
	@FXML
	public void initialize() throws SQLException {
		
		b1.setCellValueFactory(new PropertyValueFactory<>("Date"));
		b2.setCellValueFactory(new PropertyValueFactory<>("Total_Expense"));
		b3.setCellValueFactory(new PropertyValueFactory<>("Total_Earning"));
		b4.setCellValueFactory(new PropertyValueFactory<>("Total_Saving"));
		b5.setCellValueFactory(new PropertyValueFactory<>("Saving_Target"));
		b6.setCellValueFactory(new PropertyValueFactory<>("Progress"));
		
		table.getColumns().addAll(b1,b2,b3,b4,b5,b6);
		
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/planner","root","");
		PreparedStatement pst = (PreparedStatement) con.prepareStatement("select * from budgets where email=?");
		pst.setString(1,"arsal123@gmail.com");
		ResultSet r = pst.executeQuery();
		
		while(r.next()) {
			
			table.getItems().add(new budgets(r.getString("date"),r.getString("expense"),r.getString("earning"),r.getString("saving"),r.getString("target"),r.getString("progress")));
		}
	}
}
