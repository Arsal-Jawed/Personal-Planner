package application;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.mysql.jdbc.PreparedStatement;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class InfoTracker {

	@FXML
	Label name;
	@FXML
	Button Home;
	@FXML
	Button AboutUs;
	@FXML
	Button Contact;
	@FXML
	Button Logout;
	@FXML
	Label Info;
	@FXML
	TextField AskField;
	@FXML
	Button Ask;
	@FXML
	TextField Key;
	@FXML
	TextField Answer;
	@FXML
	Button Save;
	@FXML
	Label wrong;
	
	
	Main m = new Main();
	java.sql.PreparedStatement pst;
	
	@FXML
	public void initialize() throws FileNotFoundException, IOException {
		
		try (BufferedReader reader = new BufferedReader(new FileReader("current.txt"))) {
		    String word = reader.readLine();
		    name.setText(word);
		}
	}
	
	public void GotoHome(ActionEvent e) throws IOException {
		m.ChangeScene("Routine.fxml");
	}
	
	public void LogOut(ActionEvent e) throws IOException {
		m.ChangeScene("main.fxml");
	}
	
	public void SaveInfo(ActionEvent e) throws SQLException {
		
		if(Key.getText().isEmpty()||Answer.getText().isEmpty()) {
			wrong.setText("please enter both credentials to save info");
		}else {
			wrong.setText("");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/planner","root","");
			PreparedStatement pst = (PreparedStatement) con.prepareStatement("insert into infos(email,infokey,answer) values(?,?,?)");
			pst.setString(1,"arsal123@gmail.com");
			pst.setString(2, Key.getText().toString());
			pst.setString(3, Answer.getText().toString());
			pst.executeUpdate();
			
			Key.setText("");
			Answer.setText("");
		}
		
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/planner","root","");
	}
	
	public void AskInfo(ActionEvent e) throws SQLException {
		
		if(AskField.getText().isEmpty()) {
			Info.setText("please enter a key to ask me something");
		}else {
			
			String k = AskField.getText().toString();
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/planner","root","");
			PreparedStatement pst = (PreparedStatement) con.prepareStatement("select * from infos where email=? and infokey=?");
			pst.setString(1,"arsal123@gmail.com");
			pst.setString(2, k);
			ResultSet r = pst.executeQuery();
			
			if(r.next()) {
				Info.setText(r.getString("answer"));
			}else {
				Info.setText("No Info with this key");
			}
			
			AskField.setText("");
		}
		
	}
	
}
