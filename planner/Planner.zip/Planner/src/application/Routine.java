package application;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

import com.mysql.jdbc.PreparedStatement;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;
import javafx.scene.chart.XYChart.Data;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;

public class Routine {

	
	Main m = new Main();
	java.sql.PreparedStatement pst;
	
	//////////////////////////////   Menu Bar   /////////////////////////////////   Start
	@FXML
	Button SetRoutine;
	@FXML
	Button AboutUs;
	@FXML
	Button Contact;
	@FXML
	Button Logout;
	
	public void SetRoutine(ActionEvent e) throws IOException {
		
		m.ChangeScene("SetRoutine.fxml");
	}
	
	public void LogOut(ActionEvent e) throws IOException {
		m.ChangeScene("main.fxml");
	}
	//////////////////////////////   Menu Bar   ////////////////////////////////    End
	
	
	@FXML
	Label name;
	@FXML
	Button BudgetPlanner;
	@FXML
	Button EventPlanner;
	@FXML
	Button EventTracker;
	@FXML
	Button InfoTracker;
	@FXML
	TextArea CurrentTask;
	@FXML
	Label task1;
	@FXML
	Label task2;
	@FXML
	Label task3;
	@FXML
	Label task4;
	@FXML
	Label task5;
	@FXML
	Label task6;
	@FXML
	Label task7;
	@FXML
	Label task8;
	@FXML
	Label task9;
	@FXML
	Label task10;
	@FXML
	Label time1;
	@FXML
	Label time2;
	@FXML
	Label time3;
	@FXML
	Label time4;
	@FXML
	Label time5;
	@FXML
	Label time6;
	@FXML
	Label time7;
	@FXML
	Label time8;
	@FXML
	Label time9;
	@FXML
	Label time10;
	@FXML
	Button done1;
	@FXML
	Button miss1;
	@FXML
	Button done2;
	@FXML
	Button miss2;
	@FXML
	Button done3;
	@FXML
	Button miss3;
	@FXML
	Button done4;
	@FXML
	Button miss4;
	@FXML
	Button done5;
	@FXML
	Button miss5;
	@FXML
	Button done6;
	@FXML
	Button miss6;
	@FXML
	Button done7;
	@FXML
	Button miss7;
	@FXML
	Button done8;
	@FXML
	Button miss8;
	@FXML
	Button done9;
	@FXML
	Button miss9;
	@FXML
	Button done10;
	@FXML
	Button miss10;
	
	String[] Routines = {"r1","r2","r3","r4","r5","r6","r7","r8","r9","r10"};
	int[] Durations = {0,0,0,0,0,0,0,0,0,0};
	
	@FXML
	public void initialize() throws FileNotFoundException, IOException, SQLException {
		
		try (BufferedReader reader = new BufferedReader(new FileReader("current.txt"))) {
        String word = reader.readLine();
        //System.out.println("The Name: "+word);
		name.setText(word);
	}
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/planner","root","");
		PreparedStatement pst = (PreparedStatement) con.prepareStatement("select * from routinetasks");
		
		ResultSet r = pst.executeQuery();
		
		Label[] Tasks = {task1,task2,task3,task4,task5,task6,task7,task8,task9,task10};
		Label[] Times = {time1,time2,time3,time4,time5,time6,time7,time8,time9,time10};
		
		int i = 0;
		
		while (r.next()) {

	    Tasks[i].setText(r.getString("Task"));
        Times[i].setText(r.getString("Time1") + " - " + r.getString("Time2"));
		i++;
		
	    int t1 = Integer.parseInt(r.getString("Time1"));
	    int t2 = Integer.parseInt(r.getString("Time2"));
	    
	    if((t2-t1)>0) {
	    	
	    	Routines[i] = r.getString("Task");
	    	Durations[i] = t2-t1;
	    }
	}
		int dayS=LocalDate.now().getDayOfMonth();
		int Year=LocalDate.now().getYear();
		int Month=LocalDate.now().getMonthValue();
		int Days=LocalDate.now().getDayOfMonth();

			Current_Date=Integer.toString(dayS)+"-"+Integer.toString(LocalDate.now().plusMonths(k).minusMonths(b).getMonthValue())+"-"+Integer.toString(LocalDate.now().plusYears(y).minusYears(ny).getYear());
			Alarm_Task();
		
}
	
	
	//////////////////////////////////////   Progress Queue   //////////////////////////////////////    Start
	int[] ProgressQueue = new int[8];
	int front = 0, rear = 0;
	
	public void UpdateQueue(int a) {
		
		if(rear==7) {
			
			System.out.println(rear);
			for(int i=0;i<rear;i++) {ProgressQueue[i] = ProgressQueue[i+1];}
			if(rear<8) {ProgressQueue[rear] = 0;}
			rear--;
			ProgressQueue[rear++] = a;
			Routine_Progress.getData().clear();
		}else {
			System.out.println(rear);
			ProgressQueue[rear++] = a;
		}
	}
	///////////////////////////////////   Progress Queue   /////////////////////////////////////////     End
	
	//////////////////////////////////   Progress Chart   //////////////////////////////////////////     Start
	int Progress = 0;
	@FXML
	LineChart<String,Number> Routine_Progress;
	
	public void UpdateProgress(ActionEvent e) {
		
		if(e.getSource().equals(done1)||e.getSource().equals(done2)||e.getSource().equals(done3)||e.getSource().equals(done4)||
		   e.getSource().equals(done5)||e.getSource().equals(done6)||e.getSource().equals(done7)||e.getSource().equals(done8)||
		   e.getSource().equals(done9)||e.getSource().equals(done10)) {
			
			Progress+=2;
			
		}else if(e.getSource().equals(miss1)||e.getSource().equals(miss2)||e.getSource().equals(miss3)||e.getSource().equals(miss4)||
				 e.getSource().equals(miss5)||e.getSource().equals(miss6)||e.getSource().equals(miss7)||e.getSource().equals(miss8)||
				 e.getSource().equals(miss9)||e.getSource().equals(miss10)) {
			
			Progress-=2;
		}
		
		UpdateQueue(Progress);
		
		String rp = " ";
		XYChart.Series<String, Number> series = new XYChart.Series<>();
		for(int i=0 ; i<rear ; i++) {
			
			series.getData().add(new XYChart.Data<String,Number>(rp,ProgressQueue[i]));
			rp += " ";
	}	
		
		Routine_Progress.getData().add(series);
		series.getNode().setStyle("-fx-stroke: #78daf5;");
		for (XYChart.Data<String, Number> data : series.getData()) {
	        Node node = data.getNode();
	        node.setStyle("-fx-background-color: #4097d6;");
	    }
	}
	 //////////////////////////////////Progress Chart   //////////////////////////////////////////     End
	
	
	//////////////////////////////////   Pie Chart   /////////////////////////////////////////////   Start
	@FXML
	PieChart pc;
	@FXML
	Button refresh;
	
	public void RefreshPieChart(ActionEvent e) {
		
		pc.getData().clear();
		for(int i=0;i<10;i++) {
			
			if(Durations[i]>0) {
				PieChart.Data data = new PieChart.Data(Routines[i],Durations[i]);
				pc.getData().add(data);
			}
		}
		
	}
	
	/////////////////////////////////   Routing   ////////////////////////////////////////////////
	
	public void BudgetPlanner(ActionEvent e) throws IOException {
		m.ChangeScene("BudgetPlanner.fxml");
	}
	
	public void EventPlanner(ActionEvent e) throws IOException {
		m.ChangeScene("EventPlanner.fxml");
	}
	
	public void EventTracker(ActionEvent e) throws IOException {
		m.ChangeScene("EventTracker.fxml");
	}
	
	public void InfoTracker(ActionEvent e) throws IOException {
		m.ChangeScene("InfoTracker.fxml");
	}
	
	//////////////////////////////   Current Task   //////////////////////////////////////////////
	
	@FXML
	TextArea Scheduled_Task;
	static int k=0;
	static int y=0;
	int ny=0;
	static int b=0;
	public String Current_Date;
	
	public void Alarm_Task(){
		 String Status_Date=LocalDate.now().getDayOfMonth()+"-"+Integer.toString(LocalDate.now().plusMonths(k).minusMonths(b).getMonthValue())+"-"+Integer.toString(LocalDate.now().plusYears(y).minusYears(ny).getYear());
		 if(Status_Date.equals(Current_Date))
		 {
				String tsk="";
				File f = new File(Current_Date+".txt");
				try {
					FileReader fr = new FileReader(f);
					 int i;    
			          while((i=fr.read())!=-1)   
			          {
			        	  tsk=tsk+((char)i);  
			          }
			      
					fr.close();
					if(tsk.equals(""))
					{
						Scheduled_Task.setText("");
					}
					else
					{
						 Scheduled_Task.setText("the Current Task for today is \n"+tsk);
					}
					

				} catch (IOException e1) {
					
					e1.printStackTrace();
				}
		 }
		 else
		 {
			 Scheduled_Task.setText("");
		 }
		}
}
