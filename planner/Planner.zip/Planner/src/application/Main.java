package application;
	
import java.io.IOException;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.Parent;
import javafx.scene.layout.BorderPane;


public class Main extends Application {
	
	//Color-01: #4097d6
	//Color-02: #78daf5
	//Gradient:  linear-gradient(from 0.0% 100.0% to 100.0% 100.0%, #4097d6 0.0%, #7fd7eb 100.0%)
	private static Stage stg;
	
	@Override
	public void start(Stage stage) {
		try {
			
			stg = stage;
			Parent root = FXMLLoader.load(getClass().getResource("main.fxml"));
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			stage.setTitle("Personal Planner");
			stage.setWidth(1100);
			stage.setHeight(700);
			stage.setScene(scene);
			stage.show();
			
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void ChangeScene(String fxml) throws IOException{
		
		Parent pane = FXMLLoader.load(getClass().getResource(fxml));
		stg.getScene().setRoot(pane);
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
