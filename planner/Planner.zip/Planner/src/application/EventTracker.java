package application;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Font;

public class EventTracker {

	@FXML
	Label name;
	@FXML
	Button Home;
	@FXML
	Button cancel_T;
	@FXML
	Button Close_btn;
	@FXML
	Button Del_Task1;
	@FXML
	TextArea Txt_Task_Area;
	@FXML
	TextArea Scheduled_Task;
	@FXML
	TextArea show_Task;
	@FXML
	AnchorPane Dialogue_Task;
	@FXML
	AnchorPane Main_Pane;
	@FXML 
	Label movDate;
	@FXML
	Label theDate;
	@FXML
	GridPane myGrid;
	@FXML
	Button Add_Task;
	@FXML 
	Button nextbtn;
	@FXML
	Button prevbtn;
	@FXML
	Button AboutUs;
	@FXML
	Button Contact;
	@FXML
	Button Logout;
	@FXML
	Button create_T;
	static int k=0;
	static int y=0;
	int ny=0;
	static int b=0;
	public String Current_Date;
	Thread thread;
	boolean Flag=false;
	private volatile boolean stop=false;
	
	Main m = new Main();
	
	public void GotoHome(ActionEvent e) throws IOException {
		
		m.ChangeScene("Routine.fxml");
	}
	public void LogOut(ActionEvent e) throws IOException {
		m.ChangeScene("main.fxml");
	}
	
	@FXML
	public void initialize() throws FileNotFoundException, IOException {
		
		try (BufferedReader reader = new BufferedReader(new FileReader("current.txt"))) {
	        String word = reader.readLine();
	        //System.out.println("The Name: "+word);
			name.setText(word);
		}
		
		Timenow();
	int dayS=LocalDate.now().getDayOfMonth();
	int Year=LocalDate.now().getYear();
	int Month=LocalDate.now().getMonthValue();
	int Days=LocalDate.now().getDayOfMonth();

		theDate.setText(Integer.toString(dayS)+"-"+Integer.toString(LocalDate.now().plusMonths(k).minusMonths(b).getMonthValue())+"-"+Integer.toString(LocalDate.now().plusYears(y).minusYears(ny).getYear()));
		Current_Date=theDate.getText();
		
		
		for(int i =0;i<=6;i++){
			 String str=LocalDate.now().getDayOfWeek().of(i+1).toString();
			Label l1 = new Label(str);
			
			l1.setFont(new Font("Arial",10));
		
			StackPane pane = new StackPane();
			pane.getChildren().add(l1);
			myGrid.add(pane, i, 0);
			myGrid.setStyle("-fx-background-color:white;");
		}
					int Start_Ind = 0;
					int End_Ind=LocalDate.now().lengthOfMonth()+1;
					boolean flag=false;
	  String Day_first_Name=LocalDate.of(LocalDate.now().getYear(), LocalDate.now().getMonthValue(), 1).getDayOfWeek().toString();
				for(int j=0;j<=6;j++){
					 String str=LocalDate.now().getDayOfWeek().of(j+1).toString();
					 if(Day_first_Name.equals(str))
					 {
						 Start_Ind=j;
				 }
			}
			int index=1;
			 for(int r=1;r<=6;r++) {
				 for(int c=0;c<=6;c++){
					 if(index==End_Ind){
						 break;
					 }
	                if(c==Start_Ind){
						 flag=true;
					 }
					 if(flag==true)
					 {
						 Label l2 = new Label(Integer.toString(index++));
						 l2.setFont(new Font("Arial",20));
						 StackPane pane = new StackPane();
							pane.getChildren().add(l2);
							pane.setStyle("-fx-background-color:;-fx-border-color:;-fx-border-width:2;");
							Change_paneColour(pane,"white");
							myGrid.add(pane, c, r);
						
					 }
				 }
			 }

			 InitGo();
			 Initialize_Filing_Color();
	}
	
	public void LogOUT(ActionEvent e){
		 if(e.getSource().equals(Close_btn)){
			 Platform.exit();
			 thread.stop();
		 }
	}
	
	
	public void TheTasks (ActionEvent e){
		 
		 if(e.getSource().equals(Del_Task1)){
			
			 int i =0;
				
				for(Node node :myGrid.getChildren()){

				if(i>6){
					
					if(node instanceof StackPane){
						
						StackPane pane =(StackPane)node;
						String Temp=node.getStyle();
						int count=0;
						int Num1 = 0;
						int Num2 = 0;
						for(int j=0;j<Temp.length();j++){
							System.out.print(Temp.charAt(j));
							if(Temp.charAt(j)==':'){
								Num1=j;
							}
							if(Temp.charAt(j)==';'){
								Num2=j;
								count++;
								if(count==2)
								{
									//count=0;
									break;	
								}
							
							}
						}
						String str1=Temp.substring(Num1+1,Num2 );
						if(str1.equals("orange")){
							
							Label l12= (Label) pane.getChildren().get(0);
							String str2=l12.getText()+"-"+Integer.toString(LocalDate.now().plusMonths(k).minusMonths(b).getMonthValue())+"-"+Integer.toString(LocalDate.now().plusYears(y).minusYears(ny).getYear());
							try {
								PrintWriter pw = new PrintWriter(str2+".txt");
								pw.close();
							} catch (FileNotFoundException e1) {
								e1.printStackTrace();
							}
							Change_paneColour(pane,"white");
						}
					}
				}else{
					i++;
				}
			}
		 }
			
			if(e.getSource().equals(create_T)){
			String str=Txt_Task_Area.getText();
				 int i =0;
					
					for(Node node :myGrid.getChildren()){

					if(i>6){
						if(node instanceof StackPane){
							StackPane pane =(StackPane)node;
							String Temp=node.getStyle();
							int count=0;
							int Num1 = 0;
							int Num2 = 0;
							for(int j=0;j<Temp.length();j++){
								System.out.print(Temp.charAt(j));
								if(Temp.charAt(j)==':'){
									Num1=j;
								}
								if(Temp.charAt(j)==';'){
									Num2=j;
									count++;
									if(count==2){
										break;	
									}
								}
							}
							String str1=Temp.substring(Num1+1,Num2 );
							if(str1.equals("orange"))
							{
								Change_paneColour(pane,"red");
								Label l12= (Label) pane.getChildren().get(0);
								String str2=l12.getText()+"-"+Integer.toString(LocalDate.now().plusMonths(k).minusMonths(b).getMonthValue())+"-"+Integer.toString(LocalDate.now().plusYears(y).minusYears(ny).getYear());
								System.out.println(str2+"hey see this!!!...........");
								File f = new File(str2+".txt");
								try {
									FileWriter fw = new FileWriter(f);
									fw.write(Txt_Task_Area.getText());
									Txt_Task_Area.setText(null);
									fw.close();
						System.out.println("file is successfully created");
								} catch (IOException e1) {
									e1.printStackTrace();
								}
								
								System.out.println(theDate);
							}
						}
					}
					else
					{
						i++;
					}
				}
			}
		}
	
	public void Timenow(){

		System.out.println("time should show");
		 thread = new Thread ( () ->{
			SimpleDateFormat sdf = new SimpleDateFormat("hh:mm:ss");
			while(!stop)
			{
				
				try {
					Thread.sleep(1);
				
				}
				catch(Exception e)
				{
					System.out.println(e);
				}
				final String Timenow = sdf.format(new Date());
				Platform.runLater(()->{
					movDate.setText(Timenow);
				});
			}
		});	
		thread.start();
		}
	
public void Initialize_Border_Color(){
	 int i =0;
	
	for(Node node :myGrid.getChildren()){

	if(i>6){
		if(node instanceof StackPane)
		{
			
			StackPane pane =(StackPane)node;
			String Temp=node.getStyle();
			int count=0;
			int Num1 = 0;
			int Num2 = 0;
			for(int j=0;j<Temp.length();j++)
			{
				System.out.print(Temp.charAt(j));
				if(Temp.charAt(j)==':')
				{
					Num1=j;
				}
				if(Temp.charAt(j)==';')
				{
					Num2=j;
					count++;
					if(count==2)
					{
						//count=0;
						break;	
					}
				
				}
			}
			String str1=Temp.substring(0, Num1+1);
			
			String str2=Temp.substring(Num2);
			pane.setStyle(str1+str2);
		}
	}else{
		i++;
	}
}
}


public void Initialize_Filing_Color()
{
	 int i =0;
	
	for(Node node :myGrid.getChildren()){
	if(i>6){
		
		if(node instanceof StackPane){
			
			StackPane pane =(StackPane)node;
			Label l12= (Label) pane.getChildren().get(0);
			String str2=l12.getText()+"-"+Integer.toString(LocalDate.now().plusMonths(k).minusMonths(b).getMonthValue())+"-"+Integer.toString(LocalDate.now().plusYears(y).minusYears(ny).getYear());
			
			File f = new File(str2+".txt");
			if(f.length()!=0)
			{
				Change_paneColour(pane,"red");
			}
		}
	}
	else
	{
		i++;
	}
}
}



public void Change_paneColour(StackPane node,String Col)
{
	String Temp=node.getStyle();
	int Num1 = 0;
	int Num2 = 0;
	for(int i=0;i<Temp.length();i++)
	{
		System.out.print(Temp.charAt(i));
		if(Temp.charAt(i)==':')
		{
			Num1=i;
			System.out.println("i got this at"+i);
		}
		if(Temp.charAt(i)==';')
		{
			Num2=i;
			System.out.println("i got this at"+i);
			break;
		}
	}
	String str1=Temp.substring(0, Num1+1);
	
	String str2=Temp.substring(Num2);
	//System.out.println(str1+"is string1");
	//System.out.println(str2+"is string2");
//	System.out.println(str1+"blue"+str2);
	node.setStyle(str1+Col+str2);
	
	
}
public String Get_paneColour(StackPane node)
{
	String Col;
	String Temp=node.getStyle();
	int Num1 = 0;
	int Num2 = 0;
	for(int i=0;i<Temp.length();i++)
	{
		System.out.print(Temp.charAt(i));
		if(Temp.charAt(i)==':')
		{
			Num1=i;
			System.out.println("i got this at"+i);
		}
		if(Temp.charAt(i)==';')
		{
			Num2=i;
			System.out.println("i got this at"+i);
			break;
		}
	}
	String str1=Temp.substring(Num1+1, Num2);
	return str1;
	
}

   public void InitGo(){
	 int i =0;
		
		for(Node node :myGrid.getChildren()){
			
		if(i>6){
			if(node instanceof StackPane){
				
				StackPane pane =(StackPane)node;
				pane.setOnMousePressed(new EventHandler<MouseEvent>() {

					@Override
					public void handle(MouseEvent arg0) {
						Initialize_Border_Color();
						String Temp=node.getStyle();
						int count=0;
						int Num1 = 0;
						int Num2 = 0;
						for(int i=0;i<Temp.length();i++){
							System.out.print(Temp.charAt(i));
							if(Temp.charAt(i)==':')
							{
								Num1=i;
								System.out.println("i got this at"+i);
							}
							if(Temp.charAt(i)==';')
							{
								Num2=i;
								System.out.println("i got this at"+i);
								count++;
								if(count==2)
								{
									break;	
								}
							
							}
						}
						String str1=Temp.substring(0, Num1+1);
						
						String str2=Temp.substring(Num2);
						
					//	pane.setStyle("-fx-border-color:orange;-fx-border-width:2;");
						pane.setStyle(str1+"orange"+str2);
						Label l12= (Label) pane.getChildren().get(0);
						String str=l12.getText()+"-"+Integer.toString(LocalDate.now().plusMonths(k).minusMonths(b).getMonthValue())+"-"+Integer.toString(LocalDate.now().plusYears(y).minusYears(ny).getYear());
					//	show_Task.setText(str);
						String tsk="";
						File f = new File(str+".txt");
						try {
							FileReader fr = new FileReader(f);
							 int i;    
					          while((i=fr.read())!=-1)   
					          {
					        	  tsk=tsk+((char)i);  
					          }
					      
							fr.close();
							show_Task.setText(tsk);
				System.out.println("file is successfully readed");
						} catch (IOException e1) {
							
							e1.printStackTrace();
						}
						Add_Task.setVisible(true);
						if(!(Get_paneColour(pane).equals("red")))
						{
							Change_paneColour(pane,"white");
						}
						Label l1= (Label) pane.getChildren().get(0);
						l1.setStyle("-fx-text-fill:black;");
						System.out.println(pane.getStyle());
					}
					
				});
				pane.setOnMouseEntered(new EventHandler<MouseEvent>(){
				
					@Override
					public void handle(MouseEvent arg0) {
							Label l1= (Label) pane.getChildren().get(0);
							l1.setStyle("-fx-text-fill:white;");
						
						
					
						System.out.println(arg0);
						System.out.println(pane.getStyle());
						if(Get_paneColour(pane).equals("white"))
						{
							Change_paneColour(pane,"blue");
						}
					//	System.out.println("hi there my pane col is ->"+Get_paneColour(pane)); 
						
					
					System.out.println(myGrid.getColumnIndex(pane)+" ,"+myGrid.getRowIndex(pane));
						
					}
				});
				pane.setOnMouseExited(new EventHandler<MouseEvent>(){
					
					@Override
					public void handle(MouseEvent arg0) {
						
							Label l1= (Label) pane.getChildren().get(0);
							l1.setStyle("-fx-text-fill:black;");
							String Temp=node.getStyle();
							int Num1 = 0;
							int Num2 = 0;
							System.out.println(Temp);
							for(int i=0;i<Temp.length();i++)
							{
								System.out.print(Temp.charAt(i));
								if(Temp.charAt(i)==':')
								{
									Num1=i;
									//System.out.println("i got this at"+i);
								}
								if(Temp.charAt(i)==';')
								{
									Num2=i;
									break;
								//	System.out.println("i got this at"+i);
								}
							}
							String str1=Temp.substring(0, Num1+1);
							String str2=Temp.substring(Num2);
					 String Temp1=Temp.substring(Num1+1, Num2);
							if(Temp1.equals("blue"))
							{
								node.setStyle(str1+"white"+str2);
							}
					System.out.println(myGrid.getColumnIndex(pane)+" ,"+myGrid.getRowIndex(pane));
						
					}
				});
				
			}
			//first if
		}
		else
		{
			if(node instanceof StackPane)
			{
				StackPane pane =(StackPane)node;
				pane.setOnMouseEntered(new EventHandler<MouseEvent>(){
				
					@Override
					public void handle(MouseEvent arg0) {
						
							Label l1= (Label) pane.getChildren().get(0);
							l1.setStyle("-fx-text-fill:white;");
						node.setStyle("-fx-background-color:red;");
						
					}
				});
				pane.setOnMouseExited(new EventHandler<MouseEvent>(){
					
					@Override
					public void handle(MouseEvent arg0) {
						
							Label l1= (Label) pane.getChildren().get(0);
							l1.setStyle("-fx-text-fill:black;");	
						node.setStyle("-fx-background-color:white;");
					}
				});
				
			}
		}
		i++;
		}
}

   public void mybtn (ActionEvent e){
	
	if(e.getSource().equals(nextbtn)){ 
		if(LocalDate.now().minusMonths(b).plusMonths(k).getMonthValue()==12){
			y=y+1;
		}
		k=k+1;
	
		theDate.setText(LocalDate.now().toString());
		theDate.setText("1"+"/"+Integer.toString(LocalDate.now().minusMonths(b).plusMonths(k).getMonthValue())+"/"+Integer.toString(LocalDate.now().minusYears(ny).plusYears(y).getYear()));
		myGrid.getChildren().clear();
		for(int i =0;i<=6;i++){
			
			String str=LocalDate.now().getDayOfWeek().of(i+1).toString();
			Label l1 = new Label(str);
			l1.setFont(new Font("Arial",10));
			StackPane pane = new StackPane();
			pane.getChildren().add(l1);
			myGrid.add(pane, i, 0);
			myGrid.setStyle("-fx-background-color:white;");
		}
		int Start_Ind = 0;
		int End_Ind=LocalDate.now().minusMonths(b).plusMonths(k).lengthOfMonth()+1;
		System.out.println(End_Ind);
		boolean flag=false;
String Day_first_Name=LocalDate.of(LocalDate.now().minusYears(ny).plusYears(y).getYear(), LocalDate.now().minusYears(ny).plusYears(y).minusMonths(b).plusMonths(k).getMonthValue(), 1).getDayOfWeek().toString();
	for(int j=0;j<=6;j++){
		 String str=LocalDate.now().getDayOfWeek().of(j+1).toString();
		 if(Day_first_Name.equals(str))
		 {
			 Start_Ind=j;
	 }
}
int index=1;
 for(int r=1;r<=6;r++)
 {
	 for(int c=0;c<=6;c++)
	 {
		 if(index==End_Ind)
		 {
			 break;
		 }
		 if(c==Start_Ind)
		 {
			 flag=true;
		 }
		 if(flag==true)
		 {
			 Label l2 = new Label(Integer.toString(index++));
			 l2.setFont(new Font("Arial",20));
			 
			 StackPane pane = new StackPane();
		//	 pane.setStyle("-fx-border-color:grey;");
				pane.getChildren().add(l2);
				pane.setStyle("-fx-background-color:;-fx-border-color:;-fx-border-width:2;");
				Change_paneColour(pane,"white");
				myGrid.add(pane, c, r);
		 }
		
		
	 }
 }

 InitGo();
 Initialize_Filing_Color();
	}
	
	if(e.getSource().equals(prevbtn))
	{
		if(LocalDate.now().plusMonths(k).minusMonths(b).getMonthValue()==1)
		{
			y=y-1;
			//b=-2;
		}
		b=b+1;
	
	
		
		theDate.setText("1"+"/"+Integer.toString(LocalDate.now().plusMonths(k).minusMonths(b).getMonthValue())+"/"+Integer.toString(LocalDate.now().plusYears(y).minusYears(ny).getYear()));
		myGrid.getChildren().clear();
		for(int i =0;i<=6;i++)
		{
			
			 String str=LocalDate.now().getDayOfWeek().of(i+1).toString();
			Label l1 = new Label(str);
			l1.setFont(new Font("Arial",10));
			
		
			
			StackPane pane = new StackPane();
		//	pane.setStyle("-fx-border-color:grey;");
			pane.getChildren().add(l1);
		
			myGrid.add(pane, i, 0);
			myGrid.setStyle("-fx-background-color:white;");
		
		}
		int Start_Ind = 0;
		//what is the length of the month
		
		int End_Ind=LocalDate.now().minusMonths(b).plusMonths(k).lengthOfMonth()+1;
		boolean flag=false;
		//starting from which day of the week
String Day_first_Name=LocalDate.of(LocalDate.now().plusYears(y).minusYears(ny).getYear(), LocalDate.now().plusYears(y).minusYears(ny).plusMonths(k).minusMonths(b).getMonthValue(), 1).getDayOfWeek().toString();
	for(int j=0;j<=6;j++)
	{
		//nothing special ,just printing out each day of the week
		 String str=LocalDate.now().getDayOfWeek().of(j+1).toString();
		 if(Day_first_Name.equals(str))
		 {
			 Start_Ind=j;
	 }
}
int index=1;
 for(int r=1;r<=6;r++)
 {
	 for(int c=0;c<=6;c++)
	 {
		 if(index==End_Ind)
		 {
			 break;
		 }
		 if(c==Start_Ind)
		 {
			 flag=true;
		 }
		 if(flag==true)
		 {
			 Label l2 = new Label(Integer.toString(index++));
			 l2.setFont(new Font("Arial",20));
			 StackPane pane = new StackPane();
				
						pane.getChildren().add(l2);
						pane.setStyle("-fx-background-color:;-fx-border-color:;-fx-border-width:2;");
						Change_paneColour(pane,"white");
						myGrid.add(pane, c, r);
		 }
	 }
 }
 InitGo();
 Initialize_Filing_Color();
	}
}
}
