package application;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.mysql.jdbc.PreparedStatement;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;

public class EventPlanner {

	@FXML
	Label name;
	@FXML
	TableView<expense> table;
	@FXML
	TableColumn<expense,String> c1 = new TableColumn<>("Expense");
	@FXML
	TableColumn<expense,String> c2 = new TableColumn<>("Amount");
	@FXML
	TableView<events> table1;
	@FXML
	TableColumn<events,String> e1 = new TableColumn<>("Name");
	@FXML
	TableColumn<events,String> e2 = new TableColumn<>("Exp");
	@FXML
	TableColumn<events,String> e3 = new TableColumn<>("Date");
	@FXML
	TableColumn<events,String> e4 = new TableColumn<>("Ext_Budget");
	@FXML
	TableColumn<events,String> e5 = new TableColumn<>("Possibility");
	@FXML
	TextField expense_col;
	@FXML
	TextField amount_col;
	@FXML
	Button AddExpense;
	@FXML
	Button Home;
	@FXML
	Label Budget_Expense;
	@FXML
	Label Budget_Earnings;
	@FXML
	Label Budget_Savings;
	@FXML
	BarChart<String,Number> bubble;
	@FXML
	Button AboutUs;
	@FXML
	Button Contact;
	@FXML
	Button Logout;
	
	int save;
	
	Main m = new Main();
	java.sql.PreparedStatement pst;
	
	public static class expense{
		
		private String exp;
		private String amount;
		
		public expense(String e , String a) {
			
			this.exp = e;
			this.amount = a;
		}
		
		public String getExpense() {return exp;}
		public String getAmount() {return amount;}
	}
	
	public static class events{
		
		private String Name;
		private String Expense;
		private String Date;
		private String Ext_Budget;
		private String Possibility;
		
		public events(String n , String te , String d , String eb , String p) {
			
			this.Name = n;
			this.Expense = te;
			this.Date = d;
			this.Ext_Budget = eb;
			this.Possibility = p;	
		}
		
		public String getName() {return Name;}
		public String getExp() {return Expense;}
		public String getDate() {return Date;}
		public String getExt_Budget() {return Ext_Budget;}
		public String getPossibility() {return Possibility;}
	}
	
	@FXML
	public void initialize() throws FileNotFoundException, IOException, SQLException {
		
		try (BufferedReader reader = new BufferedReader(new FileReader("current.txt"))) {
	    String word = reader.readLine();
	    name.setText(word);
	}
		try (BufferedReader reader = new BufferedReader(new FileReader("BudgetData.txt"))) {
            String line = reader.readLine();
            Budget_Expense.setText("                         $"+line);
            line = reader.readLine();
            Budget_Earnings.setText("                         $"+line);
            line = reader.readLine();
            Budget_Savings.setText("                         $"+line);
            save = Integer.parseInt(line);
        } catch (IOException e) {
            System.out.println("An error occurred while reading the file: " + e.getMessage());
        }
		
		c1.setCellValueFactory(new PropertyValueFactory<>("Expense"));
		c2.setCellValueFactory(new PropertyValueFactory<>("Amount"));
		table.getColumns().addAll(c1,c2);
		
		e1.setCellValueFactory(new PropertyValueFactory<>("Name"));
		e2.setCellValueFactory(new PropertyValueFactory<>("Exp"));
		e3.setCellValueFactory(new PropertyValueFactory<>("Date"));
		e4.setCellValueFactory(new PropertyValueFactory<>("Ext_Budget"));
		e5.setCellValueFactory(new PropertyValueFactory<>("Possibility"));
		table1.getColumns().addAll(e1,e2,e3,e4,e5);
		
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/planner","root","");
		PreparedStatement pst = (PreparedStatement) con.prepareStatement("select * from events where email=?");
		pst.setString(1,"arsal123@gmail.com");
		ResultSet r = pst.executeQuery();
		while(r.next()) {
			table1.getItems().add(new events(r.getString("Name"),r.getString("Expenditures"),r.getString("Date"),r.getString("Budget"),r.getString("possibility")));
		}
    }
	
	
	public void GotoHome(ActionEvent e) throws IOException {
		m.ChangeScene("Routine.fxml");
	}
	public void LogOut(ActionEvent e) throws IOException {
		m.ChangeScene("main.fxml");
	}
	
	public void AddExpense(ActionEvent e) {
		
		String exp = expense_col.getText().toString();
		String amount = amount_col.getText().toString();
		
		if(expense_col.getText().isEmpty()||amount_col.getText().isEmpty()) {
			
			Alert error = new Alert(AlertType.ERROR);
			error.setHeaderText("Empty Fields");
			error.setContentText("please enter expense and amount for adding an expense");
			error.showAndWait();
		}else {
			
			table.getItems().add(new expense(exp,amount));
			expense_col.setText("");
			amount_col.setText("");
		}
	}
	
	///////////////////////////////    Calculate Event   ///////////////////////////////////////////////////////
	@FXML
	TextField Name_Field;
	@FXML
	TextField Ext_Field;
	@FXML
	Button CalculateEvent;
	@FXML
	Label TotalExpense;
	@FXML
	Label ExternalBudget;
	@FXML
	Label TotalBudget;
	@FXML
	Label Achieved_Target;
	@FXML
	Label EventName;
	
	public void CalculateEvent(ActionEvent e) throws SQLException {
		
		
		if(Name_Field.getText().isEmpty()||Ext_Field.getText().isEmpty()) {
			Alert error = new Alert(AlertType.ERROR);
			error.setHeaderText("Empty Fields");
			error.setContentText("please enter event name and external budget for calculating evvent possibility, if there is no external budget simply enter '0'");
		}else {
			EventName.setText(Name_Field.getText().toString());
			int totalExp = 0;
			for(int i=0 ; i<table.getItems().size() ; i++) {totalExp += Integer.parseInt(c2.getCellData(i));}
			int extBudget = Integer.parseInt(Ext_Field.getText().toString());
			int totBudget = extBudget+save;
			double percent1 = ((double)((double)totBudget/(double)totalExp))*100;
			double percent = Math.round(percent1);
			
			TotalExpense.setText("$"+Integer.toString(totalExp));
			ExternalBudget.setText("$"+Integer.toString(extBudget));
			TotalBudget.setText("$"+Integer.toString(totBudget));
			
			if(percent<=0) {Achieved_Target.setText("0%"); Achieved_Target.setStyle("-fx-text-fill: red");}
			   else if(percent<=20&&percent>0) {Achieved_Target.setText(Double.toString(percent)+"%");
			           Achieved_Target.setStyle("-fx-text-fill: red"); }
			   else if(percent<=40&&percent>20) {Achieved_Target.setText(Double.toString(percent)+"%");
			   Achieved_Target.setStyle("-fx-text-fill: orange"); }
			   else if(percent<=80&&percent>40) {Achieved_Target.setText(Double.toString(percent)+"%");
			   Achieved_Target.setStyle("-fx-text-fill: blue"); }
			   else if(percent<=100&&percent>80) {Achieved_Target.setText(Double.toString(percent)+"%");
			   Achieved_Target.setStyle("-fx-text-fill: green"); }
			   else if(percent>100) {Achieved_Target.setText("100%");
			   Achieved_Target.setStyle("-fx-text-fill: green"); }
			
			LocalDate currentDate = LocalDate.now();
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
	        String formattedDate = currentDate.format(formatter);
			
			String t1 = Name_Field.getText().toString();
			String t2 = TotalExpense.getText().toString();
			String t3 = formattedDate;
			String t4 = ExternalBudget.getText().toString();
			String t5 = Achieved_Target.getText().toString();
			
			table1.getItems().add(new events(t1,t2,t3,t4,t5));
			table1.refresh();
			
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/planner","root","");
			PreparedStatement pst = (PreparedStatement) con.prepareStatement("insert into events(email,name,date,budget,expenditures,possibility) values(?,?,?,?,?,?)");
			pst.setString(1,"arsal123@gmail.com");
			pst.setString(2,t1);
			pst.setString(3,t3);
			pst.setString(4,t4);
			pst.setString(5,t2);
			pst.setString(6,t5);
			pst.executeUpdate();
			
			XYChart.Series evseries = new XYChart.Series<String,Number>();
	        evseries.getData().add(new XYChart.Data<>(t1,percent));
	        bubble.getData().add(evseries);
	        
	        Name_Field.setText("");
	        Ext_Field.setText("");
			
		}
	}
}
